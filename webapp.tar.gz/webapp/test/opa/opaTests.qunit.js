sap.ui.define([
	"sap/ui/test/Opa5",
	"com/smartbanking/services/demokit/test/opa/arrangements/Startup",
	"com/smartbanking/services/demokit/test/opa/StartpageJourney",
	"com/smartbanking/services/demokit/test/opa/ReviewsJourney",
	"com/smartbanking/services/demokit/test/opa/BackNavigationJourney"
], function (Opa5, Startup) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "com.smartbanking.services.view.",
		autoWait: true
	});
});
