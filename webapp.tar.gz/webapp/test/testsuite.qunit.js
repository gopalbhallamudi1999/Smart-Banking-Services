sap.ui.define(function() {
	"use strict";

	return {
		name: "QUnit test suite for Smart Banking Services",
		defaults: {
			page: "ui5://test-resources/com/smartbanking/services/demokit/Test.qunit.html?testsuite={suite}&test={name}",
			qunit: {
				version: 2
			},
			sinon: {
				version: 1
			},
			ui5: {
				language: "EN",
				theme: "sap_horizon"
			},
			coverage: {
				only: "com/smartbanking/services/demokit/",
				never: [
					"com/smartbanking/services/demokit/test/"
				]
			},
			loader: {
				paths: {
					"com/smartbanking/services/demokit": "../",
                    "com/smartbanking/services": "../"
				}
			}
		},
		tests: {
			"unit/unitTests": {
				title: "Unit tests for Smart Banking Services"
			},
			"opa/opaTests": {
				title: "Integration tests for Smart Banking Services"
			}
		}
	};
});