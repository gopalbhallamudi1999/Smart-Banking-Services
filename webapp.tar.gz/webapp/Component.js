sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/smartbanking/services/model/models",
    "sap/ui/core/mvc/View"
], (UIComponent, models, View) => {
    "use strict";

    return UIComponent.extend("com.smartbanking.services.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // enable routing
            this.getRouter().initialize();
        },

        createContent: function() {
			// create root view
			return View.create({
				viewName: "com.smartbanking.services.view.App",
				type: "XML"
			});
		}
    });
});